import{l as o,a as r}from"../chunks/BvK8wjA0.js";export{o as load_css,r as start};
